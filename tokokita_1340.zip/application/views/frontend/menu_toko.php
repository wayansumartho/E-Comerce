<ul class="nav nav-pills flex-column">
    <li class="nav-item"><a href="#" class="nav-link">Beranda</a></li>
    <li class="nav-item"><a href="<?php echo site_url('Toko/produk/' . $this->uri->segment(3)); ?>" class="nav-link">Produk</a></li>
    <li class="nav-item"><a href="<?php echo site_url('Toko/transaksi/' . $this->uri->segment(3)); ?>" class="nav-link">Transaksi</a></li>
    <li class="nav-item"><a href="#" class="nav-link">Laporan</a></li>

</ul>