<ul class="nav nav-pills flex-column">
    <li class="nav-item"><a href="<?php echo site_url('Member/dashboard'); ?>" class="nav-link">Beranda</a></li>
    <li class="nav-item"><a href="<?php echo site_url('Member/transaksi'); ?>" class="nav-link">Transaksi</a></li>
    <li class="nav-item"><a href="#" class="nav-link">Riwayat Transaksi</a></li>
    <li class="nav-item"><a href="<?php echo site_url('Member/toko'); ?>" class="nav-link">Toko</a></li>
    <li class="nav-item"><a href="#" class="nav-link">Ubah Profil</a></li>
    <li class="nav-item"><a href="#" class="nav-link">Logout</a></li>
</ul>